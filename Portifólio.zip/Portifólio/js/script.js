// === TYPEWRITER ===
const texts = [
  'Souza o Mior 🤑🤟🏻',
  'Codando sozinho!',
  'Programando 24h',
  'volta pra mim Heloísa 😭'
];

let textIndex = 0;
let charIndex = 0;
let isDeleting = false;
let typewriterElement = null;

function typeWriter() {
  if (!typewriterElement) return;

  const currentText = texts[textIndex];

  if (isDeleting) {
    typewriterElement.textContent = currentText.substring(0, charIndex - 1);
    charIndex--;
  } else {
    typewriterElement.textContent = currentText.substring(0, charIndex + 1);
    charIndex++;
  }

  let typeSpeed = isDeleting ? 100 : 150;

  if (!isDeleting && charIndex === currentText.length) {
    typeSpeed = 2000; 
    isDeleting = true;
  } else if (isDeleting && charIndex === 0) {
    isDeleting = false;
    textIndex = (textIndex + 1) % texts.length;
    typeSpeed = 500;
  }

  setTimeout(typeWriter, typeSpeed);
}

// === VISUALIZAÇÕES (localStorage) ===
function updateViewCount() {
  let views = localStorage.getItem("viewCount") || 0;
  views++;
  localStorage.setItem("viewCount", views);
  document.getElementById("viewCount").textContent = views;
}

function loadViewCount() {
  let views = localStorage.getItem("viewCount") || 0;
  document.getElementById("viewCount").textContent = views;
}

// === GITHUB STATS ===
const githubUser = "hyodev0";

async function fetchGitHubStats() {
  try {
    const response = await fetch(`https://api.github.com/users/${githubUser}`);
    if (!response.ok) throw new Error("Erro na API do GitHub");

    const data = await response.json();

    const followersCount = document.getElementById("followersCount");
    const reposCount = document.getElementById("reposCount");

    if (followersCount) followersCount.textContent = data.followers ?? 0;
    if (reposCount) reposCount.textContent = data.public_repos ?? 0;

  } catch (error) {
    console.error("Erro ao buscar dados do GitHub:", error);
  }
}

// === DOM CONTENT LOADED ===
document.addEventListener('DOMContentLoaded', function() {
  const entryScreen = document.getElementById('entryScreen');
  const mainContent = document.getElementById('mainContent');
  const bgAudio = document.getElementById('bgAudio');

  typewriterElement = document.getElementById('typewriterText');

  // Carregar visualizações iniciais
  loadViewCount();

  entryScreen.addEventListener('click', function() {
    entryScreen.classList.add('hidden');

    setTimeout(() => {
      mainContent.classList.add('visible');

      if (bgAudio) {
        bgAudio.play().catch(() => console.log('Áudio não pôde ser reproduzido automaticamente'));
      }

      setTimeout(() => { typeWriter(); }, 1000);

      updateViewCount();
    }, 500);
  });

  // Animação badges
  const badges = document.querySelectorAll('.badges img');
  badges.forEach((badge, index) => {
    badge.style.animationDelay = `${index * 0.2}s`;
    badge.style.animation = 'fadeIn 1s ease-in-out both';
  });

  // Links sociais hover
  const socialLinks = document.querySelectorAll('.social-links a');
  socialLinks.forEach(link => {
    link.addEventListener('mouseenter', function() {
      this.style.transform = 'scale(1.1) rotateY(10deg)';
    });
    link.addEventListener('mouseleave', function() {
      this.style.transform = 'scale(1) rotateY(0deg)';
    });
  });

  // GitHub stats inicial + atualização automática
  fetchGitHubStats();
  setInterval(fetchGitHubStats, 30000);
});