// Typewriter
const texts = [
  "Souza o Mior 🤑🤟🏻",
  "Codando sozinho!",
  "Programando 24h",
  "Volta pra mim Heloísa 😭"
];
let textIndex = 0, charIndex = 0, isDeleting = false;
let typewriterEl;

function typeWriter() {
  if (!typewriterEl) return;
  const current = texts[textIndex];

  if (isDeleting) {
    charIndex--;
  } else {
    charIndex++;
  }

  typewriterEl.textContent = current.substring(0, charIndex);

  let speed = isDeleting ? 100 : 150;

  if (!isDeleting && charIndex === current.length) {
    speed = 2000;
    isDeleting = true;
  } else if (isDeleting && charIndex === 0) {
    isDeleting = false;
    textIndex = (textIndex + 1) % texts.length;
    speed = 500;
  }

  setTimeout(typeWriter, speed);
}

// Views
function updateViewCount() {
  let views = localStorage.getItem("viewCount") || 0;
  views++;
  localStorage.setItem("viewCount", views);
  document.getElementById("viewCount").textContent = views;
}
function loadViewCount() {
  let views = localStorage.getItem("viewCount") || 0;
  document.getElementById("viewCount").textContent = views;
}

// GitHub
const githubUser = "souzinhaaa";
async function fetchGitHubStats() {
  try {
    const response = await fetch(`https://api.github.com/users/${githubUser}`);
    if (!response.ok) throw new Error("Erro na API");
    const data = await response.json();

    document.getElementById("followersCount").textContent = data.followers ?? 0;
    document.getElementById("reposCount").textContent = data.public_repos ?? 0;
  } catch (err) {
    console.error(err);
  }
}

// Start
document.addEventListener("DOMContentLoaded", () => {
  const entryScreen = document.getElementById("entryScreen");
  const mainContent = document.getElementById("mainContent");
  const audio = document.getElementById("bgAudio");

  typewriterEl = document.getElementById("typewriterText");

  loadViewCount();

  entryScreen.addEventListener("click", () => {
    entryScreen.classList.add("hidden");
    setTimeout(() => {
      mainContent.classList.add("visible");
      updateViewCount();

      // Fade-in áudio
      audio.volume = 0;
      audio.play().catch(()=>{});
      let v = 0;
      const fade = setInterval(() => {
        if (v < 1) {
          v = Math.min(1, v + 0.05);
          audio.volume = v;
        } else {
          clearInterval(fade);
        }
      }, 200);

      setTimeout(typeWriter, 1000);
    }, 500);
  });

  fetchGitHubStats();
  setInterval(fetchGitHubStats, 30000);
});